package smrms.neonicz.gov.com.smrms;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import org.apache.http.Header;
import smrms.neonicz.gov.com.smrms.Webservice.AbstractRestClient;

public class RegistrationActivity extends Activity {
    EditText name, phone;
    Button submit;
    String mobileNo, userName;
    String REGISTRATION_URL = "http://188.165.48.255:8080/SMRMS/registration/upload";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        name = (EditText) findViewById(R.id.name);
        phone = (EditText) findViewById(R.id.phone);
        submit = (Button) findViewById(R.id.submit);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        final SharedPreferences.Editor editor = pref.edit();
        if(pref.getLong("userId",0)!=0){
            loadHome();
        }
        if (createDirectories()) {
            editor.putBoolean("foldersCreated", true);
            editor.commit();
        }
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validateViews()) {
                    if (phone.length() == 1) {
                        mobileNo = String.valueOf(phone.getText().toString());
                        userName = String.valueOf(name.getText().toString());

                        callRegister(userName, mobileNo);
                    } else {
                        Toast.makeText(getApplicationContext(), "Not a valid mobile number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please fill the details", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadHome() {
        Intent i = new Intent(RegistrationActivity.this, HomeActivity.class);
        startActivity(i);
    }

    private void callRegister(final String userName, final String mobileNo) {
        try {
            Log.e("Enter>>","1");
            final JSONObject requestParamsJson = new JSONObject();
            requestParamsJson.put("name", userName);
            requestParamsJson.put("mobileNumber", Long.valueOf(mobileNo));
            Log.e("Json:>",""+requestParamsJson.toString());
            AbstractRestClient.post(this, REGISTRATION_URL + "", requestParamsJson.toString(), new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int i, Header[] headers, byte[] bytes) {
                    Log.e("Enter:>","success");
                    if (bytes != null) {
                        String s = new String(bytes);
                        Log.e("S:>",s);
                        try {
                            JSONObject ob = new JSONObject(s);
                            Long userId = ob.getLong("userId");
                            if(userId != 0){
                                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
                                final SharedPreferences.Editor editor = pref.edit();
                                editor.putString("myMobile", mobileNo);
                                editor.putString("myName", userName);
                                editor.putLong("userId",userId);
                                editor.commit();
                                loadHome();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }

                @Override
                public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                    Log.e("RegisterService", "[onFailure]"+i+" .... "+headers);
                    if (bytes != null) {
                        String s = new String(bytes);
                        Log.e("BYtes>>>>>",""+s);
                    } else {
                        Log.e("no bytess ... ","bytes not received .. ");
                    }
                    Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            });
            Log.e("Enter:>","here");
        } catch (Exception e) {

            e.printStackTrace();
        }
        Log.e("Hai","1");
    }

    private boolean validateViews() {
        boolean emptyName = name.getText().toString().isEmpty();
        boolean emptyPhone = phone.getText().toString().isEmpty();
        if (emptyName) {
            return false;
        } else if (emptyPhone) {
            return false;
        } else if (emptyName && emptyPhone) {
            return false;
        } else {
            return true;
        }
    }

    private boolean createDirectories() {
        File root = Environment.getExternalStorageDirectory();
        boolean createdAll = true;
        File sBDirectoryProfile = new File(root.getPath() + "/SMRMS/pictures");
        if (!sBDirectoryProfile.exists()) {
            createdAll = sBDirectoryProfile.mkdirs();
        }
        return createdAll;
    }
}