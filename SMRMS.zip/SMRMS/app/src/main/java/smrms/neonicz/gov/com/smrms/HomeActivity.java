package smrms.neonicz.gov.com.smrms;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import smrms.neonicz.gov.com.smrms.util.UploadFile;

public class HomeActivity extends Activity {
    Button camera, gallery,submit;
    ImageView preview;
    TextView selectText;
    EditText description;
    private static int RESULT_LOAD_IMAGE = 1;
    Uri imageUri;
    String filePath= "";
    static int picUploadOption = 0;
    private static final int PERMISSION_REQUEST_CAMERA = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        camera = (Button) findViewById(R.id.camera);
        gallery = (Button) findViewById(R.id.gallery);
        preview = (ImageView) findViewById(R.id.preview);
        selectText = (TextView) findViewById(R.id.selectText);
        description = (EditText) findViewById(R.id.description);
        submit = (Button) findViewById(R.id.submit);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = requestCameraPermission() && requestStoragePermission();
                if (result) {
                    picUploadOption = 1;
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.TITLE, "New Picture");
                    values.put(MediaStore.Images.Media.DESCRIPTION, "From your Camera");
                    imageUri = getContentResolver().insert(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    i.putExtra(MediaStore.EXTRA_OUTPUT, imageUri
                        /*MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString()*/);
                    startActivityForResult(i, 0);
                }
            }
        });

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = requestStoragePermission();
                if (result) {
                    picUploadOption = 2;
                    Intent i = new Intent(
                            Intent.ACTION_PICK,
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(i, RESULT_LOAD_IMAGE);
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String comment = description.getText().toString();
                if (!comment.isEmpty()){
                    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
                    Long userId = pref.getLong("userId",0);
                    if(userId!=0){
                        new UploadFile().execute(filePath,String.valueOf(userId),getApplicationContext(),comment);
                    }
                    description.setText("");
                } else{
                    Toast.makeText(getApplicationContext(), "Please type a comment", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        options.inSampleSize = 2;
        options.inJustDecodeBounds = false;
        options.inTempStorage = new byte[16 * 1024];
        Log.e("case :>",picUploadOption+"");
        switch (picUploadOption) {
            case 1:
                if (resultCode == RESULT_OK) {
                    Bitmap b = null;
                    try {
                        b = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                        filePath = saveImage(b);
                        Log.e("filePath :> ",filePath);
                        filePath = compressImage(filePath);
                        Log.e("filePath 1:> ",filePath);
                        performCrop(filePath);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;

            case 2:
                if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
                    Uri selectedImage = data.getData();
                    String wholeID = null;
                    String[] filePathColumn = {MediaStore.Images.Media.DATA};
                    Cursor cursor = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                        try {
                            wholeID = DocumentsContract.getDocumentId(selectedImage);
                            String id = wholeID.split(":")[1];
                            String sel = MediaStore.Images.Media._ID + "=?";
                            if (TextUtils.isEmpty(id)) {
                                cursor = getContentResolver().query(selectedImage,
                                        filePathColumn, null, null, null);
                            } else {
                                cursor = getContentResolver().
                                        query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                                filePathColumn, sel, new String[]{id}, null);
                            }
                        } catch (Exception e) {
                            Log.e("Exception pic selcet:>", e.getMessage() + "");
                        }
                    }
                    if (cursor == null) {
                        Log.e("Enter here :> ", cursor + " cursor is null");
                        cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);

                        Log.e("Enter here :> ", cursor + " cursor renewed ");
                    }
                    if (cursor != null) {
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String picturePath = cursor.getString(columnIndex);
                        Log.e("picturePath 232:>",picturePath+"");
                        if (picturePath == null || picturePath.isEmpty()) {
                            picturePath = getImageUrlWithAuthority(getBaseContext(), selectedImage);
                        }
                        Log.e("here:>",picturePath+"");
                        String result = compressImage(picturePath);
                        cursor.close();
                        filePath = saveImage(BitmapFactory.decodeFile(result));
                        Log.e("file path 2:>>>> ",filePath);
                        performCrop(filePath);
                    } else {
                        Toast.makeText(getApplicationContext(), "upload failed, could be due to larger image size", Toast.LENGTH_SHORT).show();
                    }
                }
                break;

            case 3:
                if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                    CropImage.ActivityResult result = CropImage.getActivityResult(data);
                    Bitmap displayBitMap = null;
                    if (resultCode == RESULT_OK) {
                        Uri resultUri = result.getUri();
                        Bitmap b = null;
                        try {
                            b = MediaStore.Images.Media.getBitmap(getContentResolver(), resultUri);
                            filePath = saveImage(b);
                            displayBitMap = BitmapFactory.decodeFile(filePath, options);
                            preview.setVisibility(View.VISIBLE);
                            preview.setImageBitmap(displayBitMap);
                            showAndHideOptions();
                            Log.e("filePath3>>",""+filePath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                        Exception error = result.getError();
                    }
                }
                break;
        }
    }

    private void showAndHideOptions() {
        camera.setVisibility(View.GONE);
        gallery.setVisibility(View.GONE);
        selectText.setVisibility(View.GONE);
        description.setVisibility(View.VISIBLE);
        submit.setVisibility(View.VISIBLE);
    }

    public static String getImageUrlWithAuthority(Context context, Uri uri) {
        InputStream is = null;
        if (uri.getAuthority() != null) {
            try {
                is = context.getContentResolver().openInputStream(uri);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                return writeToTempImageAndGetPathUri(context, bmp).toString();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }finally {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


    public static Uri writeToTempImageAndGetPathUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public boolean requestCameraPermission() {
        if ((ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED)) {
            return true;
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA},
                    PERMISSION_REQUEST_CAMERA);
        }
        return false;
    }

    private void performCrop(String picUri) {
        try {
            File f = new File(picUri);
            Uri contentUri = FileProvider.getUriForFile(HomeActivity.this,
                    BuildConfig.APPLICATION_ID + ".provider",f);
            picUploadOption = 3;
            CropImage.activity(contentUri).start(this);
        } catch (ActivityNotFoundException anfe) {
            anfe.printStackTrace();
            String errorMessage = "your device doesn't support the crop action!";
            Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //Whatsapp like Image Compression in Android
    public String compressImage(String imageUri) {
        String filePath = getRealPathFromURI(imageUri);
        Bitmap scaledBitmap = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
        int actualHeight = options.outHeight != 0 ? options.outHeight : 1;
        int actualWidth = options.outWidth != 0 ? options.outWidth : 1;
        float maxHeight = 816.0f;
        float maxWidth = 612.0f;
        Log.e("actualHeight :> ", actualHeight + "");
        Log.e("actualWidth :> ", actualWidth + "");
        Log.e("maxWidth :> ", maxWidth + "");
        Log.e("maxHeight :> ", maxHeight + "");
        float imgRatio = actualWidth / actualHeight;
        float maxRatio = maxWidth / maxHeight;
        if (actualHeight > maxHeight || actualWidth > maxWidth) {
            if (imgRatio < maxRatio) {
                imgRatio = maxHeight / actualHeight;
                actualWidth = (int) (imgRatio * actualWidth);
                actualHeight = (int) maxHeight;
            } else if (imgRatio > maxRatio) {
                imgRatio = maxWidth / actualWidth;
                actualHeight = (int) (imgRatio * actualHeight);
                actualWidth = (int) maxWidth;
            } else {
                actualHeight = (int) maxHeight;
                actualWidth = (int) maxWidth;
            }
        }
        options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);
        options.inJustDecodeBounds = false;
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16 * 1024];
        try {
            bmp = BitmapFactory.decodeFile(filePath, options);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();
        }
        try {
            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();
        }
        float ratioX = actualWidth / (float) options.outWidth;
        float ratioY = actualHeight / (float) options.outHeight;
        float middleX = actualWidth / 2.0f;
        float middleY = actualHeight / 2.0f;
        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
        ExifInterface exif;
        try {
            exif = new ExifInterface(filePath);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 0);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                Log.d("EXIF", "Exif: " + orientation);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                    scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
                    true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileOutputStream out = null;
        String filename = getSMRMSFile().getAbsolutePath();
        try {
            out = new FileOutputStream(filename);
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return filename;
    }

    File getSMRMSFile() {
        File smrmsSentFilesDirectory = getBroadcastFileDirectory();
        if (!smrmsSentFilesDirectory.exists()) {
            smrmsSentFilesDirectory.mkdirs();
        }
        int numberOfFiles = smrmsSentFilesDirectory.listFiles().length;
        String lastFileName = "smrms_pic.jpg";
        File fList[] = smrmsSentFilesDirectory.listFiles();
        for (File f : fList) {
            if (f.getName().endsWith("_temp.jpg")) {
                f.delete();
            }
        }
        return new File(smrmsSentFilesDirectory, lastFileName);
    }

    File getBroadcastFileDirectory() {
        File root = Environment.getExternalStorageDirectory();
        return new File(root.getPath() + "/SMRMS/pictures");
    }

    private String getRealPathFromURI(String contentURI) {
        Log.e("conte url :> ", contentURI+"");
        Uri contentUri = Uri.parse(contentURI);
        Cursor cursor = getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }
        return inSampleSize;
    }

    private String saveImage(Bitmap finalBitmap) {
        File root = Environment.getExternalStorageDirectory();
        File smrmsDirectory = new File(root.getPath() + "/SMRMS/pictures");
        Log.e("directory :> ",smrmsDirectory.getAbsolutePath());
        if (!smrmsDirectory.exists()) {
            smrmsDirectory.mkdirs();
        }
        int numberOfFiles = smrmsDirectory.listFiles().length;
        String lastFileName = numberOfFiles + "_temp.jpg";
        File lastFile = new File(smrmsDirectory, lastFileName);
        Log.e("lastFile :> ",lastFile.getAbsolutePath()+"");
        if (lastFile.exists()) {
            lastFile.delete();
        } else {
            numberOfFiles++;
            lastFileName = numberOfFiles + "_temp.jpg";
            lastFile = new File(smrmsDirectory, lastFileName);
        }
        try {
            FileOutputStream out = new FileOutputStream(lastFile);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lastFile.getAbsolutePath();
    }

    public boolean requestStoragePermission() {
        if ((ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) && (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED)) {
            return true;
        } else {
            String[] permissionArray = new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
            };
            List<String> permissionRequestArrayList = new ArrayList<String>();
            int i = 0;
            for (String permission : permissionArray) {
                if (!(ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)) {
                    permissionRequestArrayList.add(permission);
                    ++i;
                }
            }
            String[] permissionRequestArray = permissionRequestArrayList.toArray(new String[permissionRequestArrayList.size()]);
            if (permissionRequestArrayList.size() > 0) {
                ActivityCompat.requestPermissions(this, permissionRequestArray, PERMISSION_REQUEST_CAMERA);
            }
        }
        return false;
    }
}
