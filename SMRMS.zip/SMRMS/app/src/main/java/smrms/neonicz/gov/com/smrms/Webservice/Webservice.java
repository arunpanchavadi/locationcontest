package smrms.neonicz.gov.com.smrms.Webservice;

/**
 * Created by Shalini on 3/17/2015.
 */
public class Webservice {
    public static final String FASHION_YEAR = "@FASHION_YEAR";
    public static String ATG_HOUSE_KEEPING_SPR="ATG.HOUSE_KEEPING_SPR";
    public static final int CONNECTION_TIMEOUT = 45000;
    public static final int SOCKET_TIMEOUT = 45000;
    public static final String  CONTENT_TYPE    = "Content-Type";
    public static final  String  APPLICATION_JSON = "application/json";
    public static final   String  UTF_8_ENCODING  = "UTF-8";
    public static final String SFA_GEN_ENUMS_SPR = "SFA.GEN_ENUMS_SPR";
    public static final String PRODUCTS_ON_RACK_DETAILS_SPR = "atg.PRODUCTS_ON_RACK_DETAILS_SPR";

    public static final String PRODUCTS_TO_REPLENISH_SPS="atg.PRODUCTS_TO_REPLENISH_SPS";
    public static String ATG_HOUSE_KEEPING_ACK_SPS="ATG.HOUSE_KEEPING_ACK_SPS";

    public static final String RACK_ID ="@RACK_ID" ;
    public static final String COUNT_TO_FILL ="@COUNT_TO_FILL" ;
    public static final String PRODUCTS_TO_REPLENISH_SPR ="atg.PRODUCTS_TO_REPLENISH_SPR" ;
    public static final String ITEM_CODE = "@ITEM_CODE";
    public static final String REMAINING_ITEM_COUNT ="@REMAINING_ITEM_COUNT" ;
    public static final String STOCK_ID = "@STOCK_ID";

    public static String PROC_NAME="ProcName";
    public static String DB_PARAM="dbparams";

    public static String NAME="Name";
    public static String PARAM_TYPE="ParamType";
    public static String VALUE="Value";

    public static String CODE="@CODE";
    public static String EAN_CODE="@EAN_CODE";
    public static String LAST_SYNC_DATE="@LAST_SYNC_DATE";
    public static String DEV_POST_TIME="@DEV_POST_TIME";
    public static String ID="@ID";
    public static String USER_ID="@USER_ID";
    public static String SEC_TOKEN="@SEC_TOKEN";

    public static String ITEM_CATEGORY= "@ITEM_CATEGORY";
    public static String COUNT="@COUNT";
    public static String ZONE_ID="@ZONE_ID";
    public static String GROUPING_ID= "@GROUPING_ID";
    public static String USER_NAME="@USER_NAME";

    public static String  PRODT_EAN_RFID_MAPING_SPS ="ATG.PRODT_EAN_RFID_MAPING_SPS";

    public static String ATG_PRODUCTS_TO_TRY_SPS="ATG.PRODUCTS_TO_TRY_SPS";

    public static String ATG_PRODUCTS_TO_TRY_SPS_NEW="ATG.PRODUCTS_TO_TRY_NEW_SPS";
    public static String SALES_ORDER_PRODTS_SPS="atg.SALES_ORDER_PRODTS_SPS";

    public static String ATG_PRODUCTS_TO_TRY_SPR="ATG.PRODUCTS_TO_TRY_NEW_SPR";
    public static String ATG_PRODUCTS_TO_TRY_ACK_SPS="atg.PRODUCTS_TO_REPLENISH_ACK_SPS";
    public static String ATG_PRODUCTS_TO_TRY_ACK_SPS_BACKSTORE="atg.PRODUCTS_TO_TRY_ACK_SPS";

    public static String  GET_CROSS_SELLING_ITEM="ATG.GET_CROSS_SELLING_ITEMS_RFID_SPR";





    public static String GET_LATEST_FASHION_ITEMS_SPR="atg.GET_LATEST_FASHION_ITEMS_SPR";
    public static String  GET_LIKE_ITEM="atg.GET_LIKE_ITEMS_RFID_SPR";
    public static String RFIDCode="@RFIDCode";
    public static String EANCODE="@EANCode";

    public static String  GET_PRDT_DETAILS="ATG.GET_PRODT_DETAILS_RFID_SPR";

    public static String  GET_PRDT_DETAILS_BY_EAN="atg.GET_PRODT_DETAILS_EAN_SPR";

}
