package smrms.neonicz.gov.com.smrms.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;

/**
 * Created by arunp_000 on 12/19/2016.
 */
public class UploadFile extends AsyncTask {
    @Override
    protected Object doInBackground(Object[] params) {
        String filePath = (String) params[0];
        String mobileNumber = (String) params[1];
        String comment = (String) params[3];
        Context context = (Context) params[2];
        Log.e("FilePath:>", filePath);
        Log.e("Mobile :> ", mobileNumber+"");
        try {
            Bitmap bm = BitmapFactory.decodeFile(filePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 75, bos);
            byte[] data = bos.toByteArray();
            HttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost("http://188.165.48.255:8080/SMRMS/uploadFile/upload");
            ByteArrayBody bab = new ByteArrayBody(data, "profile.jpg");
           // Log.e("1", "here");
            MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
            reqEntity.addPart("uploadedFile", bab);
            reqEntity.addPart("userId", new StringBody(String.valueOf(mobileNumber)));
            reqEntity.addPart("comment", new StringBody(comment));
            postRequest.setEntity(reqEntity);
           // Log.e("2", "here");
            HttpResponse response = httpClient.execute(postRequest);

            //Log.e("3", "here");
            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
           // Log.e("4", "here");
            String sResponse;
           // Log.e("5", "here");
            StringBuilder s = new StringBuilder();
           // Log.e("response :>", reader.toString());
            while ((sResponse = reader.readLine()) != null) {
                s = s.append(sResponse);
            }
            Log.e("Response: ", s.toString() + "");
            JSONObject ob = new JSONObject(s.toString());
            String status = ob.getString("status");
            String message = ob.getString("message");
            Log.e("status:>>>",""+status);
            Log.e("message:>>>",""+message);
            if ("Success".equals(status)){
                Log.e("enter:>","success");
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
            return s.toString();
        } catch (Exception e) {
            Log.e(e.getClass().getName(), e.getMessage());
        }
        return null;
    }

    protected void onPostExecute(String result) {
        Log.e("Response :>> >>>> ", result);
    }
}
