package smrms.neonicz.gov.com.smrms.Webservice;

import android.app.Activity;
import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;

/**
 * Created by Shalini on 3/17/2015.
 */
public class AbstractRestClient {

    private static final String BASE_URL = "http://api.twitter.com/1/";

    private static AsyncHttpClient client = new AsyncHttpClient();


/*    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get((url), params, responseHandler);


    }*/



    public static void post(Context context, String url, String requestHeader , AsyncHttpResponseHandler responseHandler) {

        try {
            StringEntity se = null;
            se = new StringEntity(requestHeader,Webservice.UTF_8_ENCODING);
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, Webservice.APPLICATION_JSON));
            se.setContentEncoding(Webservice.UTF_8_ENCODING);
            client.addHeader( Webservice.CONTENT_TYPE,  Webservice.APPLICATION_JSON);
            client.post(context, (url), se, null, responseHandler);
            client.setConnectTimeout(Webservice.CONNECTION_TIMEOUT);
            client.setTimeout(Webservice.CONNECTION_TIMEOUT);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void post(Activity context, String url, String requestHeader , AsyncHttpResponseHandler responseHandler) {
        try {
            //Log.e("calling url", "" + url);
            //Log.e("calling requestHeader", "" + requestHeader);
            StringEntity se = null;
            se = new StringEntity(requestHeader,Webservice.UTF_8_ENCODING);
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, Webservice.APPLICATION_JSON));
            se.setContentEncoding(Webservice.UTF_8_ENCODING);
            client.addHeader( Webservice.CONTENT_TYPE,  Webservice.APPLICATION_JSON);
            client.post(context, (url), se, null, responseHandler);
            client.setConnectTimeout(Webservice.CONNECTION_TIMEOUT);
            client.setTimeout(Webservice.CONNECTION_TIMEOUT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void postToSave(Activity context, String url, String requestHeader, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        try {
//            StringEntity se = null;
//            se = new StringEntity(requestHeader,Webservice.UTF_8_ENCODING);
//            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, Webservice.APPLICATION_JSON));
//            se.setContentEncoding(Webservice.UTF_8_ENCODING);
            client.addHeader(Webservice.CONTENT_TYPE, Webservice.APPLICATION_JSON);
//            client.post((context, (url), se, null, responseHandler);
            client.post(context, (url), params, responseHandler);
            client.setConnectTimeout(Webservice.CONNECTION_TIMEOUT);
            client.setTimeout(Webservice.CONNECTION_TIMEOUT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.addHeader(Webservice.CONTENT_TYPE, Webservice.APPLICATION_JSON);
        client.post((url), params, responseHandler);
        client.setConnectTimeout(Webservice.CONNECTION_TIMEOUT);
        client.setTimeout(Webservice.CONNECTION_TIMEOUT);

    }

    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.addHeader(Webservice.CONTENT_TYPE, Webservice.APPLICATION_JSON);
        client.get((url), params, responseHandler);
        client.setConnectTimeout(Webservice.CONNECTION_TIMEOUT);
        client.setTimeout(Webservice.CONNECTION_TIMEOUT);

    }


    private static String getAbsoluteUrl(String relativeUrl) {
        return BASE_URL + relativeUrl;
    }
}
