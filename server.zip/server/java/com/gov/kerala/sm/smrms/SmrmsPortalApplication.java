package com.gov.kerala.sm.smrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmrmsPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmrmsPortalApplication.class, args);
	}
}
