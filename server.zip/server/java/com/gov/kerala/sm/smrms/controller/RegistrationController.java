package com.gov.kerala.sm.smrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gov.kerala.sm.smrms.dao.impl.UserRepository;
import com.gov.kerala.sm.smrms.model.User;

@RestController
@RequestMapping(value="/registration")
public class RegistrationController {

	@Autowired
	UserRepository userRepository;
	
	@RequestMapping(value = "/upload", method=RequestMethod.POST)
	public String registerUser(@RequestBody User user) {
		long userId = userRepository.saveUser(user);
		if(userId>0){
			return "{\"userId\":\""+userId+"\"}";
		}else{
			return "{\"userId\":\"0\"}";
		}
	}
	
}
