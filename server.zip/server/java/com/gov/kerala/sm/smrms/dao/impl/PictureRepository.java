package com.gov.kerala.sm.smrms.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

@Repository
public class PictureRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public long saveContest(String userId, String picturePath, String comment){
		
		final String sql = "INSERT INTO  photocontest  (   userId ,  picturePath ,  comment ) VALUES ( ?, ?, ?) ";
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {

				PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, userId);
				ps.setString(2,picturePath);
				ps.setString(3, comment);
				return ps;
			}
		}, holder);
		Long pictureId = Long.valueOf(holder.getKeys().get("GENERATED_KEY").toString());
		return pictureId;
	}
}
