package com.gov.kerala.sm.smrms.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import javax.servlet.MultipartConfigElement;
import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.gov.kerala.sm.smrms.dao.impl.PictureRepository;

@RestController
@RequestMapping(value = "/uploadFile")
// Max uploaded file size (here it is 20 MB)
@MultipartConfig(fileSizeThreshold = 20971520)
public class UploadController {

	@Autowired
	PictureRepository pictureRepository;
	
	@Bean(name="multipartResolver")
	public CommonsMultipartResolver  multipartResolver() {
		return new CommonsMultipartResolver();
	}

	@RequestMapping(value = "/upload", method=RequestMethod.POST)
	public String uploadFile(@RequestParam("uploadedFile") MultipartFile uploadedFileRef, @RequestParam("userId")String userId, @RequestParam("comment") String comment) {
		// Get name of uploaded file.
		String fileName = uploadedFileRef.getOriginalFilename();
		//System.out.println("uploadedFileRef ::> "+uploadedFileRef);
		//System.out.println("userId:>"+userId);
		// Path where the uploaded file will be stored.
		//System.out.println("User Id ::> "+userId);
		//System.out.println("uploadType Id ::> "+uploadType);
		String rootPath = null;
		String ipAddress = null;
		Date date = new Date();
		rootPath = "/home/liferay-portal-6.2-ce-ga4/tomcat-7.0.42/webapps/smsrmsuserDirectory/"+userId+"/"+date.getTime()+"/";
		ipAddress = "http://188.165.48.255:8080/smsrmsuserDirectory/"+userId+"/"+date.getTime();
		String path = rootPath+fileName ;
		System.out.println("path ::> "+path);
		File f = new File(rootPath);
		if(!f.exists()){
			System.out.println("Mk dirs njknvke");
			f.mkdirs();
		}
		// This buffer will store the data read from 'uploadedFileRef'
		byte[] buffer = new byte[1000];
		System.out.println("Affter buffer");
		// Now create the output file on the server.
		File outputFile = new File(path);
		System.out.println("Affter buffer :>>> "+outputFile.getPath());
		try {
			if (outputFile.exists()) {
				System.out.println("Out put file Exisits");
				if (outputFile.delete()) {
					System.out.println("Out put file deleted");
					outputFile.createNewFile();
					System.out.println("new file created");
				}
			} else {
				outputFile.createNewFile();
			}
		    FileOutputStream fos = new FileOutputStream(outputFile); 
		    fos.write(uploadedFileRef.getBytes());
		    fos.close(); 
		    pictureRepository.saveContest(userId, ipAddress+"/"+fileName, comment);
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e){
			e.printStackTrace();
		}finally {
			/*try {
				//reader.close();
				//writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
				return "{\"status\":\"Failed\",\"message\":\"File upload Failed\",\"path\":\""+ipAddress+"/"+fileName+"\"}";
			}*/
		}

		return "{\"status\":\"Success\",\"message\":\"File uploaded Successfully\",\"path\":\""+ipAddress+"/"+fileName+"\"}";
	}

}